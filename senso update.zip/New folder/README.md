# nebula Nuke Bot! - by 0tro#6666

to use do pip install -r requirements.txt

Just a nice looking cmd self bot with some nuke commands, you can expand on it as you wish and add anything you need or take the code for reference etc, I simply made this because I was bored and wanted to make something nice.
# Information!
This was coded using Python 3.8.2 so make sure you are up to date on your updates and make sure that you have everything installed before saying its shit and broken etc.

If you wanna leave credit feel free to do so but I highly doubt anyone would but thanks to anyone who uses this and leaves credit, it is greatly appreciated <3
# Advice
If you don't want to use the .json for storing your token and other shit you might add to it, you can always change it to a .env for whatever reason you choose.


